package data;

/**
 * 프로그램의 세부 설정 데이터 클래스
 */
public class Setting {
    public static int FILE_SEND_FAIL_LIMIT = 3;
}
